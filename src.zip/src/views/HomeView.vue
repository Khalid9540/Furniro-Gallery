<script setup>

</script>

<template>
  <main>
    <TheWelcome />
  </main>
</template>
